// export let companyData =
//   {Scotiabank: {rating: null} }
    
// export const updateRating = (company, newRating) => {
//  companyData[company].rating = newRating
// }

// data.js
//export let companyData = { Scotiabank: { rating: null } };

//export function updateRating(company, rating) {
 //   companyData[company].rating = rating;
//}

